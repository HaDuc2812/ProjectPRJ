/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Wines;

/**
 *
 * @author HA DUC
 */
public class DAO extends DBContext {
    public List<Wines> getAll(){
        List<Wines> wines = new ArrayList();    
        String sql = "select * from Wines";
        try{
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while(rs.next()){
                Wines wi = new Wines(rs.getString("wine_id"), rs.getString("name"), rs.getString("type"), rs.getString("country"), rs.getInt("year"), rs.getInt("stock_quantity"), rs.getDouble("price"), rs.getString("image_url"), rs.getString("description"), rs.getInt("supplier_id"));
                wines.add(wi);
            }
            
        }catch(SQLException e){
            System.out.println(e);
        }
        return wines;
    }
     public static void main(String[] args) {
        DAO d = new DAO();
        List<Wines> wine = d.getAll();
        if (!wine.isEmpty()) {  // Prevent IndexOutOfBoundsException
            System.out.println(wine.get(0).getName());
        } else {
            System.out.println("No wines found.");
        }
    }
}
