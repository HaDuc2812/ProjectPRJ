/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author HA DUC
 */
public class Wines {
//    wine_id INT PRIMARY KEY IDENTITY(1,1),
//    name VARCHAR(255) NOT NULL,
//    type VARCHAR(100) NOT NULL,  -- Red, White, Rose, Sparkling, etc.
//    country VARCHAR(100),
//    year INT,
//    price DECIMAL(10,2) NOT NULL,
//    stock_quantity INT NOT NULL,
//    image_url VARCHAR(255), -- URL for wine images
//    description TEXT,
//    supplier_id INT,
//    FOREIGN KEY (supplier_id) REFERENCES Suppliers(supplier_id)
    private String wine_id;
    private String name, type, country;
    private int year, stock_quantity;
    private double price;
    private String image_url, description;
    private int supplier_id;

    public Wines() {
    }

    public Wines(String wine_id, String name, String type, String country, int year, int quantity, double price, String image_url, String description, int supplier_id) {
        this.wine_id = wine_id;
        this.name = name;
        this.type = type;
        this.country = country;
        this.year = year;
        this.stock_quantity = quantity;
        this.price = price;
        this.image_url = image_url;
        this.description = description;
        this.supplier_id = supplier_id;
    }

    public String getWine_id() {
        return wine_id;
    }

    public void setWine_id(String wine_id) {
        this.wine_id = wine_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getStock_quantity() {
        return stock_quantity;
    }

    public void setStock_quantity(int stock_quantity) {
        this.stock_quantity = stock_quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSupplier_id() {
        return supplier_id;
    }

    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }
    
}
