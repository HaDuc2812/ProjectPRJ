/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.util.ArrayList;
import java.util.List;
import model.Category;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import model.Product;

/**
 *
 * @author admin
 */
public class DAO extends DBContext {

    public List<Category> getAll() {
        List<Category> list = new ArrayList<>();
        String sql = "select * from Categories";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Category ct = new Category(rs.getInt("id"), rs.getString("name"), rs.getString("describe"));
                list.add(ct);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }
    //lay toan bo san pham ra

    public List<Product> getProducts() {
        List<Product> list = new ArrayList();
        String sql = "select p.ID, p.name, p.quantity, p.price, p.releaseDate, p.describe, p.image, c.id as cid, c.name as cname, c.describe as cdescribe\n"
                + "from products p inner join Categories c on (p.cid=c.ID)";
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                Category c = new Category(rs.getInt("cid"), rs.getString("cname"), rs.getString("cdescribe"));
                Product p = new Product(rs.getString("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"), rs.getDate("releaseDate"), rs.getString("describe"), rs.getString("image"), c);
                list.add(p);
            }
        } catch (SQLException e) {

        }
        return list;
    }

    public List<Product> getProductsByCid(int cid) {
        List<Product> list = new ArrayList();
        String sql = "select p.ID, p.name, p.quantity, p.price, p.releaseDate, p.describe, p.image, c.id as cid, c.name as cname, c.describe as cdescribe\n"
                + "from products p inner join Categories c on (p.cid=c.ID) where 1=1";
        if(cid>0){
            sql+=" and cid="+cid;
        }
        try {
            PreparedStatement st = connection.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            st.setInt(1, cid);
            while (rs.next()) {
                Category c = new Category(rs.getInt("cid"), rs.getString("cname"), rs.getString("cdescribe"));
                Product p = new Product(rs.getString("id"), rs.getString("name"), rs.getInt("quantity"), rs.getDouble("price"), rs.getDate("releaseDate"), rs.getString("describe"), rs.getString("image"), c);
                list.add(p);
            }
        } catch (SQLException e) {

        }
        return list;
    }

    public static void main(String[] args) {
        DAO d = new DAO();
        List<Category> list = d.getAll();
        System.out.println(list.get(0).getName());
    }
}
