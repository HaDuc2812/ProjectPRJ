/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Category;
import model.Product;
import model.Wines;
import utils.DBContext;

/**
 *
 * @author HA DUC
 */
public class DAO {

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Wines> getAllWines() {
        List<Wines> list = new ArrayList<>();
        String sql = "select * from Wines";
        try {
            conn = new DBContext().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Wines(
                        rs.getInt("wine_id"), // wine_id as int
                        rs.getString("name"), // name as String
                        rs.getInt("category_id"), // category_id as int
                        rs.getString("country"), // country as String
                        rs.getInt("year"), // year as int
                        rs.getDouble("price"), // price as double
                        rs.getInt("stock_quantity"), // stock_quantity as int
                        rs.getString("image_url"), // image_url as String
                        rs.getString("description"), // description as String
                        rs.getInt("supplier_id") // supplier_id as int
                ));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Category> getAllCategory() {
        List<Category> list = new ArrayList<>();
        String sql = "select * from Categories";
        try {
            conn = new DBContext().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Category(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3)));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Wines> getWinesByCID(String cid) {
        List<Wines> list = new ArrayList<>();
        String sql = "SELECT * FROM Wines WHERE category_id = ?;";
        try {
            conn = new DBContext().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, cid);  // Set the parameter BEFORE executing the query.
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Wines(
                        rs.getInt("wine_id"), // wine_id as int
                        rs.getString("name"), // name as String
                        rs.getInt("category_id"), // category_id as int
                        rs.getString("country"), // country as String
                        rs.getInt("year"), // year as int
                        rs.getDouble("price"), // price as double
                        rs.getInt("stock_quantity"), // stock_quantity as int
                        rs.getString("image_url"), // image_url as String
                        rs.getString("description"), // description as String
                        rs.getInt("supplier_id") // supplier_id as int
                ));
            }
            rs.close();
            st.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Wines getWinesByID(String id) {
        Wines wine = null;
        String sql = "SELECT wine_id, name, category_id, country, year, price, stock_quantity, image_url, description, supplier_id "
                + "FROM Wines WHERE wine_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            // Convert the String id to an int before setting the parameter
            ps.setInt(1, Integer.parseInt(id));
            rs = ps.executeQuery();
            if (rs.next()) {
                wine = new Wines(
                        rs.getInt("wine_id"),
                        rs.getString("name"),
                        rs.getInt("category_id"),
                        rs.getString("country"),
                        rs.getInt("year"),
                        rs.getDouble("price"),
                        rs.getInt("stock_quantity"),
                        rs.getString("image_url"),
                        rs.getString("description"),
                        rs.getInt("supplier_id")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NumberFormatException ne) {
            System.err.println("The provided wine_id is not a valid number: " + id);
            ne.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return wine;
    }

    public List<Wines> getWinesByName(String txtSearch) {
        List<Wines> list = new ArrayList<>();
        String sql = "select * from Wines wi where wi.name like ?";
        try {
            conn = new DBContext().getConnection();
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, "%" + txtSearch + "%");  // Set the parameter BEFORE executing the query.
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Wines(
                        rs.getInt("wine_id"), // wine_id as int
                        rs.getString("name"), // name as String
                        rs.getInt("category_id"), // category_id as int
                        rs.getString("country"), // country as String
                        rs.getInt("year"), // year as int
                        rs.getDouble("price"), // price as double
                        rs.getInt("stock_quantity"), // stock_quantity as int
                        rs.getString("image_url"), // image_url as String
                        rs.getString("description"), // description as String
                        rs.getInt("supplier_id") // supplier_id as int
                ));
            }
            rs.close();
            st.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Product getProduct(int id) {
        Product product = null;
        String sql = "SELECT * FROM Product WHERE product_id = ?";
        try (Connection conn = DBContext.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    product = new Product();
                    product.setProductId(rs.getInt("product_id"));
                    product.setName(rs.getString("name"));
                    product.setPrice(rs.getBigDecimal("price"));
                    product.setStockQuantity(rs.getInt("stock_quantity"));
                    product.setDescription(rs.getString("description"));
                    product.setCountry(rs.getString("country"));
                    product.setYear(rs.getInt("year"));
                    product.setImageUrl(rs.getString("image_url"));
                    product.setQuantity(rs.getInt("quantity")); // This will be 0 by default.
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return product;
    }

//    public static void main(String[] args) {
//        DAO dao = new DAO();
//        List<Wines> wineList = dao.getWinesByCID("1");
//        for (Wines wines : wineList) {
//            System.out.println(wines);
//        }
//    }
}
